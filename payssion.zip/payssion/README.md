Payssion WooCommerce extension
=================

<h3>Getting Started</h3>

<h4>Installation</h4>
Upload the `payssion` folder to /wp-content/plugins/ on your server.

<h4>Setup</h4>

1. Log in to Wordpress administration, click on the `Plugins` tab.
2. Find `WooCommerce Payssion` in the plugin overview and activate it.
3. Go to WooCommerce -> Settings -> Checkout -> Payssion, or you just click `Settings` under `WooCommerce Payssion` plugin.
4. Fill in your `API Key` and `Secret Key`, which you can find after logging at your Payssion account. Click `Save changes`.
5. Activate the alternative payment methods you want to use. Please note the `Status` of `Payssion` payment method is disabled in order to prevent it to show as a payment option.
